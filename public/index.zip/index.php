<?php

$json = file_get_contents('estado-cidade.json');
$list = json_decode($json, true);
$estados = $list['estados'];

$cidades = [];

foreach ($estados as $estado) {
    $sigla = strtolower($estado['sigla']);

    foreach ($estado['cidades'] as $municipio) {
        $cidades[$sigla][] = sprintf("https://vlvadvogados.com/advogado-%s-%s", generateSlug($municipio), $sigla);
    }
}

function generateSlug($string) {
    // Converte a string para minúsculas
    $string = strtolower($string);

    // Remove caracteres especiais
    $string = preg_replace('/[^\p{L}\p{N}\s]/u', '', $string);

    // Substitui espaços por hífens
    $string = preg_replace('/\s+/', '-', $string);

    // Substitui letras com acentos por suas versões sem acento
    $string = str_replace(
        ['à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ð', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ'],
        ['a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'o', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y'],
        $string
    );

    // Remove caracteres especiais novamente
    $string = preg_replace('/[^a-z0-9\s-]/', '', $string);

    // Remove espaços extras
    $string = preg_replace('/\s+/', ' ', $string);

    // Remove hífens extras
    $string = preg_replace('/\-\-+/', '-', $string);

    // Remove hífens no início e no final
    $string = trim($string, '-');

    return $string;
}