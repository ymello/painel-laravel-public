<x-filament-panels::page>

    Clique abaixo para consultar seu CPF ou CNPJ.

    <div class="fi-ac gap-3 flex flex-wrap items-center justify-start">
        <x-filament::link href="https://www.consultoriac3.com.br/consulta/consulta.php">Consultar CPF/CNPJ</x-filament::link>
    </div>

    Ao Clicar você concorda com os

    <div class="fi-ac gap-3 flex flex-wrap items-center justify-start">
        <x-filament::link href="https://www.consultoriac3.com.br/uso-privacidade/">Termos de Uso e Políticas de Privacidade</x-filament::link>
    </div>

</x-filament-panels::page>
