<x-filament-panels::page>
    <script>
        function currencyMask(el) {
            let value = el.value.replace(/\D/g, '');

            if (value === '') {
                el.value = '0,00';
                return;
            }

            value = value.replace(/([0-9]{2})$/g, ".$1")
            value = parseFloat(value).toFixed(2).toString();

            el.value = value.replace('.', ',')
                .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");
        }

        function currencyMaskBackup(el) {
            const value = el.value.replace(/\D/g, '')
                .replace(/([0-9]{2})$/g, ",$1")
                .replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.");

            if (value === 'NaN') {
                el.value = '';
                return;
            }

            el.value = value;
        }
    </script>

    <livewire:customer-form />

    <x-filament-panels::form @class(['hidden' => !$this->showForm])>
        {{ $this->form }}

        @if($this->showForm)
            <x-filament-panels::form.actions
                :actions="$this->getCachedFormActions()"
                :full-width="$this->hasFullWidthFormActions()"
            />
        @endif
    </x-filament-panels::form>

    @includeWhen(!blank($this->calculoResults), 'filament.pages.forms.'.$formType->value)
</x-filament-panels::page>
